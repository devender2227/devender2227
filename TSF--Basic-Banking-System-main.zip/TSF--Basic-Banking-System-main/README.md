# TSF--Basic-Banking-System
> <h4>JOYDEV GORAI</h4>
>
>The Sparks Foundation Task : Web Development Intern
>
>#GRIPSEPT22


<br><br><br><br>

VISIT TSF: <br>
<a href="https://www.facebook.com/thesparksfoundation.info"> Facebook</a> ||
<a href="https://www.linkedin.com/company/the-sparks-foundation/"> Linkedin</a>||
<a href="https://twitter.com/tsfsingapore"> Twitter</a>||
<a href="https://instagram.com/thesparksfoundation.info"> Instagram</a>||
<a href="https://medium.com/thesparksfoundation"> Medium</a>||<br>





## Introduction
>  
> A web application used to transfer money between two users. And having 12 user in it.


## Technologies Used:
- HTML
- CSS
- JAVASCRIPT
- Bootstrap

### Flow of the website
Home > View Customer > Select One Customer > Transfer Money > Select Receiver > View Customer

## Below are the screenshots of the website: 
> <img width="649" alt="1" src="https://github.com/devil535/TSF--Basic-Banking-System/blob/main/Screenshots/1.PNG?raw=true"><br><br><br>
> <img width="645" alt="2" src="https://github.com/devil535/TSF--Basic-Banking-System/blob/main/Screenshots/2.PNG?raw=true"><br><br><br>
>
>
> <img width="651" alt="3" src="https://github.com/devil535/TSF--Basic-Banking-System/blob/main/Screenshots/4.PNG?raw=true"><br><br><br>
> <img width="668" alt="5" src="https://github.com/devil535/TSF--Basic-Banking-System/blob/main/Screenshots/6.PNG?raw=true"><br><br><br>
> <img width="658" alt="4" src="https://github.com/devil535/TSF--Basic-Banking-System/blob/main/Screenshots/5.PNG?raw=true"><br><br><br>
